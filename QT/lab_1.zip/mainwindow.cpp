#include "mainwindow.h"
#include "ui_mainwindow.h"

double num_first = 0;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    connect(ui->button_0, SIGNAL(clicked()), this, SLOT(digits_numbers()));
    connect(ui->button_1, SIGNAL(clicked()), this, SLOT(digits_numbers()));
    connect(ui->button_2, SIGNAL(clicked()), this, SLOT(digits_numbers()));
    connect(ui->button_3, SIGNAL(clicked()), this, SLOT(digits_numbers()));
    connect(ui->button_4, SIGNAL(clicked()), this, SLOT(digits_numbers()));
    connect(ui->button_5, SIGNAL(clicked()), this, SLOT(digits_numbers()));
    connect(ui->button_6, SIGNAL(clicked()), this, SLOT(digits_numbers()));
    connect(ui->button_7, SIGNAL(clicked()), this, SLOT(digits_numbers()));
    connect(ui->button_8, SIGNAL(clicked()), this, SLOT(digits_numbers()));
    connect(ui->button_9, SIGNAL(clicked()), this, SLOT(digits_numbers()));
    connect(ui->button_change, SIGNAL(clicked()), this, SLOT(operations()));
    connect(ui->button_sin, SIGNAL(clicked()), this, SLOT(operations()));
    connect(ui->button_plus, SIGNAL(clicked()), this, SLOT(math_operations()));
    connect(ui->button_minus, SIGNAL(clicked()), this, SLOT(math_operations()));
    connect(ui->button_X, SIGNAL(clicked()), this, SLOT(math_operations()));
    connect(ui->button_division, SIGNAL(clicked()), this, SLOT(math_operations()));
    connect(ui->button_pow, SIGNAL(clicked()), this, SLOT(math_operations()));

    ui->button_plus->setCheckable(true);
    ui->button_minus->setCheckable(true);
    ui->button_X->setCheckable(true);
    ui->button_division->setCheckable(true);
    ui->button_pow->setCheckable(true);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::digits_numbers()
{
    QPushButton *button = (QPushButton *) sender();

    double num;
    QString new_label;
    num = (ui->result_show->text() + button->text()).toDouble();
    new_label = QString::number(num, 'g', 13);

    ui->result_show->setText(new_label);
}

void MainWindow::on_button_dot_clicked()
{
    if (!(ui->result_show->text().contains('.')))
        ui->result_show->setText(ui->result_show->text() + ".");
}

void MainWindow::operations()
{
    QPushButton *button = (QPushButton *) sender();

    double num;
    QString new_label;

    if (button->text() == "+/-") {
        num = (ui->result_show->text()).toDouble();
        num = num * (-1);
        new_label = QString::number(num, 'g', 13);

        ui->result_show->setText(new_label);
    } else if (button->text() == "sin") {
        num = (ui->result_show->text()).toDouble();
        num = std::sin(num);
        new_label = QString::number(num, 'g', 13);

        ui->result_show->setText(new_label);
    }
}


void MainWindow::math_operations()
{
    QPushButton *button = (QPushButton *) sender();

    num_first = ui->result_show->text().toDouble();
    ui->result_show->setText("0");
    null_math();
    button->setChecked(true);

}


void MainWindow::on_button_C_clicked()
{
    null_math();
    num_first = 0;
    ui->result_show->setText("0");
}


void MainWindow::on_button_equal_clicked()
{
    double labelNumber, num_second;
    QString new_label;

    num_second = ui->result_show->text().toDouble();

    if (ui->button_plus->isChecked()){
        labelNumber = num_first + num_second;
        new_label = QString::number(labelNumber, 'g', 13);

        ui->result_show->setText(new_label);
    } else if (ui->button_minus->isChecked()) {
        labelNumber = num_first - num_second;
        new_label = QString::number(labelNumber, 'g', 13);

        ui->result_show->setText(new_label);
    } else if (ui->button_X->isChecked()) {
        labelNumber = num_first * num_second;
        new_label = QString::number(labelNumber, 'g', 13);

        ui->result_show->setText(new_label);
    } else if (ui->button_division->isChecked()) {
        if (num_second == 0) {
            ui->result_show->setText("Error");
        } else {
            labelNumber = num_first / num_second;
            new_label = QString::number(labelNumber, 'g', 13);

            ui->result_show->setText(new_label);
        }

    } else if (ui->button_pow->isChecked()) {
        labelNumber = std::pow(num_first, num_second);
        new_label = QString::number(labelNumber, 'g', 13);

        ui->result_show->setText(new_label);
    }
}

void MainWindow::null_math() {
    ui->button_plus->setChecked(false);
    ui->button_minus->setChecked(false);
    ui->button_X->setChecked(false);
    ui->button_division->setChecked(false);
    ui->button_pow->setChecked(false);
}

