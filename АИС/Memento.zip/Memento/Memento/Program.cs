﻿using System;
using System.Collections.Generic;

class EditorMemento
{
    public string Content { get; private set; } 

    public EditorMemento(string content)
    {
        Content = content;
    }
}

class Editor
{
    public string Content { get; set; } 

    public EditorMemento CreateMemento()
    {
        Console.WriteLine($"Saving editor state: {Content}");
        return new EditorMemento(Content);
    }

    public void RestoreMemento(EditorMemento memento)
    {
        Content = memento.Content;
        Console.WriteLine($"Restoring editor state to: {Content}"); 
    }
}

class History
{
    public Stack<EditorMemento> States { get; } = new Stack<EditorMemento>();
}


public class Program
{
    public static void Main(string[] args)
    {
        Editor editor = new Editor();
        History history = new History();

        editor.Content = "Hello, world!";
        Console.WriteLine($"Current editor content: {editor.Content}");

        history.States.Push(editor.CreateMemento());

        editor.Content = "Hello, Memento pattern!";
        Console.WriteLine($"Current editor content: {editor.Content}");

        history.States.Push(editor.CreateMemento());

        Console.WriteLine("Undoing...");
        editor.RestoreMemento(history.States.Pop());
        Console.WriteLine($"Current editor content: {editor.Content}");


        Console.WriteLine("Undoing again...");
        editor.RestoreMemento(history.States.Pop());
        Console.WriteLine($"Current editor content: {editor.Content}");


        Console.ReadKey();
    }
}