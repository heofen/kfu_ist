﻿using System;

interface IDocumentState
{
    void Edit(Document document);
    void SubmitForReview(Document document);
    void Approve(Document document);
    void Reject(Document document);
    void Print(Document document);
}

class Document
{
    public IDocumentState State { get; set; }

    public Document()
    {
        State = new DraftState();
    }

    public void Edit()
    {
        State.Edit(this);
    }

    public void SubmitForReview()
    {
        State.SubmitForReview(this);
    }

    public void Approve()
    {
        State.Approve(this);
    }

    public void Reject()
    {
        State.Reject(this);
    }

    public void Print()
    {
        State.Print(this);
    }

    public void DisplayState()
    {
        Console.WriteLine($"Document state: {State.GetType().Name}");
    }
}

class DraftState : IDocumentState
{
    public void Edit(Document document)
    {
        Console.WriteLine("Document is being edited.");
    }

    public void SubmitForReview(Document document)
    {
        Console.WriteLine("Document is submitted for review.");
        document.State = new ReviewState();
    }

    public void Approve(Document document)
    {
        Console.WriteLine("Cannot approve in Draft state.");
    }

    public void Reject(Document document)
    {
       Console.WriteLine("Cannot reject in Draft state.");
    }
    public void Print(Document document)
    {
         Console.WriteLine("Cannot print in Draft state.");
    }
}

class ReviewState : IDocumentState
{
    public void Edit(Document document)
    {
       Console.WriteLine("Cannot edit in Review state.");
    }

    public void SubmitForReview(Document document)
    {
        Console.WriteLine("Already in review.");
    }

    public void Approve(Document document)
    {
        Console.WriteLine("Document is approved and published!");
        document.State = new PublishedState();
    }

    public void Reject(Document document)
    {
        Console.WriteLine("Document is rejected, returned to draft.");
        document.State = new DraftState();
    }
    public void Print(Document document)
    {
         Console.WriteLine("Cannot print in Review state.");
    }
}

class PublishedState : IDocumentState
{
    public void Edit(Document document)
    {
        Console.WriteLine("Cannot edit in Published state.");
    }

    public void SubmitForReview(Document document)
    {
        Console.WriteLine("Cannot submit for review in Published state.");
    }

    public void Approve(Document document)
    {
        Console.WriteLine("Already published.");
    }

    public void Reject(Document document)
    {
        Console.WriteLine("Cannot reject in Published state.");
    }
    public void Print(Document document)
    {
        Console.WriteLine("Document is being printed.");
    }
}

class Program
{
    static void Main(string[] args)
    {
        Document document = new Document();
        bool running = true;

        while (running)
        {
            Console.WriteLine("[1] Edit Document");
            Console.WriteLine("[2] Submit for Review");
            Console.WriteLine("[3] Approve Document");
            Console.WriteLine("[4] Reject Document");
            Console.WriteLine("[5] Print Document");
            Console.WriteLine("[6] Display Document State");
            Console.WriteLine("[0] Exit");
            Console.Write("Choose an option: ");

            string choice = Console.ReadLine();
            Console.WriteLine();

            switch (choice)
            {
                case "1":
                    document.Edit();
                    break;
                case "2":
                    document.SubmitForReview();
                    break;
                case "3":
                    document.Approve();
                    break;
                case "4":
                    document.Reject();
                    break;
                case "5":
                    document.Print();
                    break;
                case "6":
                    document.DisplayState();
                    break;
                case "0":
                    running = false;
                    Console.WriteLine("Exiting...");
                    break;
                default:
                    Console.WriteLine("Invalid option. Please try again.");
                    break;
            }
        }
    }
}
