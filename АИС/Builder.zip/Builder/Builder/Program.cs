﻿using System;

class UserProfile
{
    public string Name { get; set; }
    public int Age { get; set; }

    public override string ToString()
    {
        return $"User Profile:\nName: {Name}\nAge: {Age}\n";
    }
}

abstract class UserProfileBuilder
{
    public UserProfile UserProfile { get; private set; }

    public void CreateUserProfile()
    {
        UserProfile = new UserProfile();
    }

    public abstract void SetName(string name);
    public abstract void SetAge(int age);
    public abstract UserProfile GetUserProfile();
}

class ConcreteUserProfileBuilder : UserProfileBuilder
{
    public override void SetName(string name)
    {
        UserProfile.Name = name;
    }

    public override void SetAge(int age)
    {
        UserProfile.Age = age;
    }

    public override UserProfile GetUserProfile()
    {
        return UserProfile;
    }
}

class ProfileDirector
{
    public UserProfile ConstructProfile(UserProfileBuilder builder, string name, int age)
    {
        builder.CreateUserProfile();
        builder.SetName(name);
        builder.SetAge(age);
        return builder.GetUserProfile();
    }
}

class Program
{
    static void Main(string[] args)
    {
        ProfileDirector director = new ProfileDirector();
        ConcreteUserProfileBuilder builder = new ConcreteUserProfileBuilder();

        UserProfile profile1 = director.ConstructProfile(builder, "Alice", 30);
        Console.WriteLine(profile1);

        UserProfile profile2 = director.ConstructProfile(builder, "Bob", 25);
        Console.WriteLine(profile2);

        Console.Read();
    }
}