﻿using System;
using System.Collections.Generic;

class Song
{
    public string Title { get; set; }
    public string Artist { get; set; }

    public Song(string title, string artist)
    {
        Title = title;
        Artist = artist;
    }

    public override string ToString()
    {
        return $"{Title} - {Artist}";
    }
}

interface IPlaylistIterator
{
    bool HasNext();
    Song Next();
}

interface IPlaylistCollection
{
    IPlaylistIterator CreateIterator();
    int Count { get; }
    Song this[int index] { get; }
}

class PlaylistIterator : IPlaylistIterator
{
    private readonly IPlaylistCollection _playlist;
    private int currentIndex = 0;

    public PlaylistIterator(IPlaylistCollection playlist)
    {
        _playlist = playlist;
    }

    public bool HasNext()
    {
        return currentIndex < _playlist.Count;
    }

    public Song Next()
    {
        if (HasNext())
        {
            return _playlist[currentIndex++];
        }
        return null;
    }
}

class Playlist : IPlaylistCollection
{
    private readonly List<Song> _songs = new List<Song>();

    public void AddSong(Song song)
    {
        _songs.Add(song);
    }

    public int Count
    {
        get { return _songs.Count; }
    }

    public Song this[int index]
    {
        get
        {
            if (index >= 0 && index < _songs.Count)
            {
                return _songs[index];
            }
            return null; 
        }
    }

    public IPlaylistIterator CreateIterator()
    {
        return new PlaylistIterator(this);
    }

    public void PlayAllSongs()
    {
        IPlaylistIterator iterator = CreateIterator();
        Console.WriteLine("Playing playlist:");
        while (iterator.HasNext())
        {
            Song song = iterator.Next();
            Console.WriteLine($"    Now playing: {song}");
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
        Playlist myPlaylist = new Playlist();
        myPlaylist.AddSong(new Song("Bohemian Rhapsody", "Queen"));
        myPlaylist.AddSong(new Song("Imagine", "John Lennon"));
        myPlaylist.AddSong(new Song("Stairway to Heaven", "Led Zeppelin"));

        IPlaylistIterator playlistIterator = myPlaylist.CreateIterator();
        while (playlistIterator.HasNext())
        {
            Song song = playlistIterator.Next();
            Console.WriteLine($"Song: {song}");
        }

        myPlaylist.PlayAllSongs();


        bool running = true;

        while (running)
        {
            Console.WriteLine("[1] Add Song to Playlist");
            Console.WriteLine("[2] Play Playlist");
            Console.WriteLine("[0] Exit");
            Console.Write("Choose an option: ");

            string choice = Console.ReadLine();
            Console.WriteLine();

            switch (choice)
            {
                case "1":
                    Console.Write("Enter song title: ");
                    string title = Console.ReadLine();
                    Console.Write("Enter artist: ");
                    string artist = Console.ReadLine();
                    myPlaylist.AddSong(new Song(title, artist));
                    Console.WriteLine("Song added to playlist.");
                    break;
                case "2":
                    myPlaylist.PlayAllSongs();
                    break;
                case "0":
                    running = false;
                    Console.WriteLine("Exiting...");
                    break;
                default:
                    Console.WriteLine("Invalid option. Please try again.");
                    break;
            }
        }
    }
}