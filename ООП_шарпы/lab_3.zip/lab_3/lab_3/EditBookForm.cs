﻿using System;
using System.Text.Json.Serialization;
using System.Windows.Forms;
using System.ComponentModel;

namespace LibraryApp
{
    public partial class EditBookForm : Form
    {
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Book Book { get; private set; }

        public EditBookForm()
        {
            InitializeComponent();
            Book = new Book();
        }

        public EditBookForm(Book book)
        {
            InitializeComponent();
            Book = book;
            titleTextBox.Text = book.Title;
            authorTextBox.Text = book.Author;
            isbnTextBox.Text = book.ISBN;
            publicationYearNumericUpDown.Value = book.PublicationYear;
            availableCheckBox.Checked = book.IsAvailable;
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(titleTextBox.Text))
            {
                MessageBox.Show("Пожалуйста, введите название книги.", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (string.IsNullOrWhiteSpace(authorTextBox.Text))
            {
                MessageBox.Show("Пожалуйста, введите автора книги.", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (string.IsNullOrWhiteSpace(isbnTextBox.Text))
            {
                MessageBox.Show("Пожалуйста, введите ISBN книги.", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (publicationYearNumericUpDown.Value < 0 || publicationYearNumericUpDown.Value > DateTime.Now.Year)
            {
                MessageBox.Show("Некорректный год публикации.", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Book.Title = titleTextBox.Text;
            Book.Author = authorTextBox.Text;
            Book.ISBN = isbnTextBox.Text;
            Book.PublicationYear = (int)publicationYearNumericUpDown.Value;
            Book.IsAvailable = availableCheckBox.Checked;

            DialogResult = DialogResult.OK;
            Close();
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}