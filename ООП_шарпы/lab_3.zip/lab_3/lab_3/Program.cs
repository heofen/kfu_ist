using LibraryApp;

namespace lab_3
{
    internal static class Program
    {
                                [STAThread]
        static void Main()
        {
                                    ApplicationConfiguration.Initialize();
            Application.Run(new MainForm());
        }
    }
}