using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows.Forms;

namespace LibraryApp
{
    public partial class MainForm : Form
    {
        private List<Book> _books = new List<Book>();
        private const string _dataFilePath = "library_data.json";

        public MainForm()
        {
            InitializeComponent();
            LoadData();
            UpdateDataGridView();
        }

        private void LoadData()
        {
            if (File.Exists(_dataFilePath))
            {
                try
                {
                    string jsonString = File.ReadAllText(_dataFilePath);
                    _books = JsonSerializer.Deserialize<List<Book>>(jsonString);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"������ ��� �������� ������: {ex.Message}", "������", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void SaveData()
        {
            try
            {
                string jsonString = JsonSerializer.Serialize(_books);
                File.WriteAllText(_dataFilePath, jsonString);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"������ ��� ���������� ������: {ex.Message}", "������", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void UpdateDataGridView()
        {
            dataGridViewBooks.DataSource = null;
            dataGridViewBooks.DataSource = _books;
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            EditBookForm editForm = new EditBookForm();
            if (editForm.ShowDialog() == DialogResult.OK)
            {
                _books.Add(editForm.Book);
                SaveData();
                UpdateDataGridView();
            }
        }

        private void editButton_Click(object sender, EventArgs e)
        {
            if (dataGridViewBooks.SelectedRows.Count > 0)             {
                Book selectedBook = (Book)dataGridViewBooks.SelectedRows[0].DataBoundItem;
                EditBookForm editForm = new EditBookForm(selectedBook);
                if (editForm.ShowDialog() == DialogResult.OK)
                {
                    SaveData();
                    UpdateDataGridView();
                }

            }
            else
            {
                MessageBox.Show("����������, �������� ����� ��� ��������������.", "��������������", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            if (dataGridViewBooks.SelectedRows.Count > 0)             {
                if (MessageBox.Show("�� �������, ��� ������ ������� ��� �����?", "�������������", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    Book selectedBook = (Book)dataGridViewBooks.SelectedRows[0].DataBoundItem;
                    if (selectedBook != null)
                    {
                        _books.Remove(selectedBook);
                        SaveData();
                        UpdateDataGridView();
                    }

                }
            }
            else
            {
                MessageBox.Show("����������, �������� ����� ��� ��������.", "��������������", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void ��������ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            addButton_Click(sender, e);
        }

        private void �������������ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            editButton_Click(sender, e);
        }

        private void �������ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            deleteButton_Click(sender, e);
        }

        private void dataGridViewBooks_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right && e.RowIndex >= 0)
            {
                dataGridViewBooks.ClearSelection();
                dataGridViewBooks.Rows[e.RowIndex].Selected = true;
                contextMenuStripBooks.Show(dataGridViewBooks, dataGridViewBooks.PointToClient(Cursor.Position));
            }
        }

    }
}