﻿using System.Text.Json.Serialization;
namespace LibraryApp
{
    public class Book
    {
        public string Title { get; set; } = "";
        public string Author { get; set; } = "";
        public string ISBN { get; set; } = "";
        public int PublicationYear { get; set; }
        public bool IsAvailable { get; set; }

        public Book() { }

        public override string ToString()
        {
            return $"{Title} - {Author}";
        }
    }
}