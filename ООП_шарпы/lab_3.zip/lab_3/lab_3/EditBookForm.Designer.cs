﻿namespace LibraryApp
{
    partial class EditBookForm
    {
                                private System.ComponentModel.IContainer components = null;

                                        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

                                        private void InitializeComponent()
        {
            this.titleLabel = new System.Windows.Forms.Label();
            this.titleTextBox = new System.Windows.Forms.TextBox();
            this.authorLabel = new System.Windows.Forms.Label();
            this.authorTextBox = new System.Windows.Forms.TextBox();
            this.isbnLabel = new System.Windows.Forms.Label();
            this.isbnTextBox = new System.Windows.Forms.TextBox();
            this.publicationYearLabel = new System.Windows.Forms.Label();
            this.publicationYearNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.availableCheckBox = new System.Windows.Forms.CheckBox();
            this.saveButton = new System.Windows.Forms.Button();
            this.cancelButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.publicationYearNumericUpDown)).BeginInit();
            this.SuspendLayout();
                                                this.titleLabel.AutoSize = true;
            this.titleLabel.Location = new System.Drawing.Point(13, 13);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(57, 13);
            this.titleLabel.TabIndex = 0;
            this.titleLabel.Text = "Название";
                                                this.titleTextBox.Location = new System.Drawing.Point(111, 10);
            this.titleTextBox.Name = "titleTextBox";
            this.titleTextBox.Size = new System.Drawing.Size(261, 20);
            this.titleTextBox.TabIndex = 1;
                                                this.authorLabel.AutoSize = true;
            this.authorLabel.Location = new System.Drawing.Point(13, 40);
            this.authorLabel.Name = "authorLabel";
            this.authorLabel.Size = new System.Drawing.Size(37, 13);
            this.authorLabel.TabIndex = 2;
            this.authorLabel.Text = "Автор";
                                                this.authorTextBox.Location = new System.Drawing.Point(111, 37);
            this.authorTextBox.Name = "authorTextBox";
            this.authorTextBox.Size = new System.Drawing.Size(261, 20);
            this.authorTextBox.TabIndex = 3;
                                                this.isbnLabel.AutoSize = true;
            this.isbnLabel.Location = new System.Drawing.Point(13, 67);
            this.isbnLabel.Name = "isbnLabel";
            this.isbnLabel.Size = new System.Drawing.Size(32, 13);
            this.isbnLabel.TabIndex = 4;
            this.isbnLabel.Text = "ISBN";
                                                this.isbnTextBox.Location = new System.Drawing.Point(111, 64);
            this.isbnTextBox.Name = "isbnTextBox";
            this.isbnTextBox.Size = new System.Drawing.Size(261, 20);
            this.isbnTextBox.TabIndex = 5;
                                                this.publicationYearLabel.AutoSize = true;
            this.publicationYearLabel.Location = new System.Drawing.Point(13, 94);
            this.publicationYearLabel.Name = "publicationYearLabel";
            this.publicationYearLabel.Size = new System.Drawing.Size(86, 13);
            this.publicationYearLabel.TabIndex = 6;
            this.publicationYearLabel.Text = "Год публикации";
                                                this.publicationYearNumericUpDown.Location = new System.Drawing.Point(111, 91);
            this.publicationYearNumericUpDown.Maximum = new decimal(new int[] {
            2024,
            0,
            0,
            0});
            this.publicationYearNumericUpDown.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.publicationYearNumericUpDown.Name = "publicationYearNumericUpDown";
            this.publicationYearNumericUpDown.Size = new System.Drawing.Size(120, 20);
            this.publicationYearNumericUpDown.TabIndex = 7;
            this.publicationYearNumericUpDown.Value = new decimal(new int[] {
            2023,
            0,
            0,
            0});
                                                this.availableCheckBox.AutoSize = true;
            this.availableCheckBox.Location = new System.Drawing.Point(16, 121);
            this.availableCheckBox.Name = "availableCheckBox";
            this.availableCheckBox.Size = new System.Drawing.Size(78, 17);
            this.availableCheckBox.TabIndex = 8;
            this.availableCheckBox.Text = "В наличии";
            this.availableCheckBox.UseVisualStyleBackColor = true;
                                                this.saveButton.Location = new System.Drawing.Point(216, 157);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(75, 23);
            this.saveButton.TabIndex = 9;
            this.saveButton.Text = "Сохранить";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
                                                this.cancelButton.Location = new System.Drawing.Point(297, 157);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(75, 23);
            this.cancelButton.TabIndex = 10;
            this.cancelButton.Text = "Отмена";
            this.cancelButton.UseVisualStyleBackColor = true;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
                                                this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 192);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.availableCheckBox);
            this.Controls.Add(this.publicationYearNumericUpDown);
            this.Controls.Add(this.publicationYearLabel);
            this.Controls.Add(this.isbnTextBox);
            this.Controls.Add(this.isbnLabel);
            this.Controls.Add(this.authorTextBox);
            this.Controls.Add(this.authorLabel);
            this.Controls.Add(this.titleTextBox);
            this.Controls.Add(this.titleLabel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "EditBookForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Редактировать книгу";
            ((System.ComponentModel.ISupportInitialize)(this.publicationYearNumericUpDown)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.TextBox titleTextBox;
        private System.Windows.Forms.Label authorLabel;
        private System.Windows.Forms.TextBox authorTextBox;
        private System.Windows.Forms.Label isbnLabel;
        private System.Windows.Forms.TextBox isbnTextBox;
        private System.Windows.Forms.Label publicationYearLabel;
        private System.Windows.Forms.NumericUpDown publicationYearNumericUpDown;
        private System.Windows.Forms.CheckBox availableCheckBox;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Button cancelButton;
    }
}